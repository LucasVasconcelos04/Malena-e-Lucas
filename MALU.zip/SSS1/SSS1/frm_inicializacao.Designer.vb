﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_inicializacao
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_inicializacao))
        btn_iniciar = New Button()
        img_initialize = New PictureBox()
        CType(img_initialize, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btn_iniciar
        ' 
        btn_iniciar.BackColor = Color.Black
        btn_iniciar.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn_iniciar.ForeColor = Color.White
        btn_iniciar.Location = New Point(148, 5)
        btn_iniciar.Name = "btn_iniciar"
        btn_iniciar.Size = New Size(226, 32)
        btn_iniciar.TabIndex = 0
        btn_iniciar.Text = "Clique na tela para continuar"
        btn_iniciar.UseVisualStyleBackColor = False
        ' 
        ' img_initialize
        ' 
        img_initialize.BackColor = Color.Coral
        img_initialize.BorderStyle = BorderStyle.FixedSingle
        img_initialize.Image = CType(resources.GetObject("img_initialize.Image"), Image)
        img_initialize.Location = New Point(-1, -2)
        img_initialize.Name = "img_initialize"
        img_initialize.Size = New Size(508, 492)
        img_initialize.SizeMode = PictureBoxSizeMode.StretchImage
        img_initialize.TabIndex = 1
        img_initialize.TabStop = False
        ' 
        ' frm_inicializacao
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(505, 488)
        Controls.Add(btn_iniciar)
        Controls.Add(img_initialize)
        Name = "frm_inicializacao"
        StartPosition = FormStartPosition.CenterScreen
        Text = "INICIALIZAÇÃO"
        CType(img_initialize, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents btn_iniciar As Button
    Friend WithEvents img_initialize As PictureBox
End Class
