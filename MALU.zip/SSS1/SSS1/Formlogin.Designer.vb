﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Formlogin
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Formlogin))
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        chk_visu = New CheckBox()
        txt_cpf = New MaskedTextBox()
        txt_senha = New MaskedTextBox()
        btn_entrar = New Button()
        lbl_ircadastro = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BorderStyle = BorderStyle.Fixed3D
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(110, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(202, 197)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Arial Narrow", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.HighlightText
        Label1.Location = New Point(161, 221)
        Label1.Name = "Label1"
        Label1.Size = New Size(99, 37)
        Label1.TabIndex = 1
        Label1.Text = "LOGIN"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.HighlightText
        Label2.Location = New Point(77, 292)
        Label2.Name = "Label2"
        Label2.Size = New Size(29, 15)
        Label2.TabIndex = 2
        Label2.Text = "CPF"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.HighlightText
        Label3.Location = New Point(77, 355)
        Label3.Name = "Label3"
        Label3.Size = New Size(46, 15)
        Label3.TabIndex = 3
        Label3.Text = "SENHA"
        ' 
        ' chk_visu
        ' 
        chk_visu.AutoSize = True
        chk_visu.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        chk_visu.ForeColor = SystemColors.Control
        chk_visu.Location = New Point(183, 377)
        chk_visu.Name = "chk_visu"
        chk_visu.Size = New Size(75, 17)
        chk_visu.TabIndex = 7
        chk_visu.Text = "Visualizar"
        chk_visu.UseVisualStyleBackColor = True
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Location = New Point(77, 310)
        txt_cpf.Mask = "000,000,000-00"
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(80, 23)
        txt_cpf.TabIndex = 8
        ' 
        ' txt_senha
        ' 
        txt_senha.Location = New Point(77, 374)
        txt_senha.Name = "txt_senha"
        txt_senha.PasswordChar = "*"c
        txt_senha.Size = New Size(100, 23)
        txt_senha.TabIndex = 9
        ' 
        ' btn_entrar
        ' 
        btn_entrar.BackColor = Color.Coral
        btn_entrar.BackgroundImage = CType(resources.GetObject("btn_entrar.BackgroundImage"), Image)
        btn_entrar.Location = New Point(299, 394)
        btn_entrar.Name = "btn_entrar"
        btn_entrar.Size = New Size(55, 46)
        btn_entrar.TabIndex = 13
        btn_entrar.UseVisualStyleBackColor = False
        ' 
        ' lbl_ircadastro
        ' 
        lbl_ircadastro.AutoSize = True
        lbl_ircadastro.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        lbl_ircadastro.ForeColor = SystemColors.HotTrack
        lbl_ircadastro.Location = New Point(5, 462)
        lbl_ircadastro.Name = "lbl_ircadastro"
        lbl_ircadastro.Size = New Size(197, 15)
        lbl_ircadastro.TabIndex = 14
        lbl_ircadastro.Text = "Se não possui cadastro clique aqui!"
        ' 
        ' Formlogin
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(405, 486)
        Controls.Add(lbl_ircadastro)
        Controls.Add(btn_entrar)
        Controls.Add(txt_senha)
        Controls.Add(txt_cpf)
        Controls.Add(chk_visu)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox1)
        Name = "Formlogin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "LOGIN"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents chk_visu As CheckBox
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents txt_senha As MaskedTextBox
    Friend WithEvents btn_entrar As Button
    Friend WithEvents lbl_ircadastro As Label
End Class
