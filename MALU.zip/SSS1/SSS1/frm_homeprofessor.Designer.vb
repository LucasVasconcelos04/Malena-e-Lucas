﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_homeprofessor
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_homeprofessor))
        PictureBox1 = New PictureBox()
        Label3 = New Label()
        Button3 = New Button()
        btn_voltar = New Button()
        Label1 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BorderStyle = BorderStyle.FixedSingle
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(145, 6)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(183, 171)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 18
        PictureBox1.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.HighlightText
        Label3.Location = New Point(168, 276)
        Label3.Name = "Label3"
        Label3.Size = New Size(132, 16)
        Label3.TabIndex = 16
        Label3.Text = "SEU CRONOGRAMA"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Coral
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.Location = New Point(168, 295)
        Button3.Name = "Button3"
        Button3.Size = New Size(130, 122)
        Button3.TabIndex = 12
        Button3.UseVisualStyleBackColor = False
        ' 
        ' btn_voltar
        ' 
        btn_voltar.BackColor = SystemColors.HotTrack
        btn_voltar.Image = CType(resources.GetObject("btn_voltar.Image"), Image)
        btn_voltar.Location = New Point(415, 6)
        btn_voltar.Name = "btn_voltar"
        btn_voltar.Size = New Size(41, 34)
        btn_voltar.TabIndex = 26
        btn_voltar.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Arial Narrow", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.HighlightText
        Label1.Location = New Point(114, 199)
        Label1.Name = "Label1"
        Label1.Size = New Size(269, 37)
        Label1.TabIndex = 27
        Label1.Text = "HOME PROFESSOR"
        ' 
        ' frm_homeprofessor
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaptionText
        ClientSize = New Size(466, 448)
        Controls.Add(Label1)
        Controls.Add(btn_voltar)
        Controls.Add(PictureBox1)
        Controls.Add(Label3)
        Controls.Add(Button3)
        Name = "frm_homeprofessor"
        StartPosition = FormStartPosition.CenterScreen
        Text = "HOME"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents btn_voltar As Button
    Friend WithEvents Label1 As Label
End Class
