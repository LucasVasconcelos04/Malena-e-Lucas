﻿Public Class Formlogin
    Private Sub btn_entrar_Click(sender As Object, e As EventArgs) Handles btn_entrar.Click
        Try
            If String.IsNullOrEmpty(txt_cpf.Text) Or String.IsNullOrEmpty(txt_senha.Text) Then
                MsgBox("Preencha todos os campos!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "select * from tb_adm where cpf = '" & txt_cpf.Text & "' and senha_de_acesso = '" & txt_senha.Text & "'"
                rs = db.Execute(sql)
                If rs.EOF = False Then 'Se existir na table no banco de dados
                    MsgBox("Seja bem vindo(a)!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    limpar_campos_login()
                    Me.Hide()
                    frm_homeproprietario.Show()
                Else
                    sql = "select * from tb_funcionarios where cpf = '" & txt_cpf.Text & "' and senha_de_acesso = '" & txt_senha.Text & "' and id_cargo = 2"
                    rs = db.Execute(sql)
                    If rs.EOF = False Then 'Se existir na table no banco de dados
                        MsgBox("Seja bem vindo(a)!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                        limpar_campos_login()
                        Me.Hide()
                        frm_homeprofessor.Show()
                    Else
                        sql = "select * from tb_funcionarios where cpf = '" & txt_cpf.Text & "' and senha_de_acesso = '" & txt_senha.Text & "' and id_cargo = 3"
                        rs = db.Execute(sql)
                        If rs.EOF = False Then 'Se existir na table no banco de dados
                            MsgBox("Seja bem vindo(a)!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                            limpar_campos_login()
                            Me.Hide()
                            frm_homerecepcao.Show()
                        Else
                            MsgBox("Login inválido!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Formlogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
    End Sub

    Private Sub chk_visu_CheckedChanged(sender As Object, e As EventArgs) Handles chk_visu.CheckedChanged
        If chk_visu.Checked Then
            txt_senha.PasswordChar = ControlChars.NullChar
        Else
            txt_senha.PasswordChar = "*"
        End If
    End Sub

    Private Sub lbl_ircadastro_Click(sender As Object, e As EventArgs) Handles lbl_ircadastro.Click
        Me.Hide()
        frm_cadastro.Show()
    End Sub
End Class