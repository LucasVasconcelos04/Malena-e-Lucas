﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_homerecepcao
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_homerecepcao))
        Button3 = New Button()
        Label3 = New Label()
        PictureBox1 = New PictureBox()
        Label5 = New Label()
        btn_voltar = New Button()
        Button4 = New Button()
        Label4 = New Label()
        Button5 = New Button()
        Label6 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.Coral
        Button3.Image = CType(resources.GetObject("Button3.Image"), Image)
        Button3.Location = New Point(218, 461)
        Button3.Name = "Button3"
        Button3.Size = New Size(143, 122)
        Button3.TabIndex = 2
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.HighlightText
        Label3.Location = New Point(261, 442)
        Label3.Name = "Label3"
        Label3.Size = New Size(62, 16)
        Label3.TabIndex = 6
        Label3.Text = "CURSOS"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BorderStyle = BorderStyle.FixedSingle
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(202, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(191, 185)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 8
        PictureBox1.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Arial Narrow", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = SystemColors.HighlightText
        Label5.Location = New Point(173, 212)
        Label5.Name = "Label5"
        Label5.Size = New Size(253, 37)
        Label5.TabIndex = 9
        Label5.Text = "HOME RECEPÇÃO"
        ' 
        ' btn_voltar
        ' 
        btn_voltar.Image = CType(resources.GetObject("btn_voltar.Image"), Image)
        btn_voltar.Location = New Point(494, 46)
        btn_voltar.Name = "btn_voltar"
        btn_voltar.Size = New Size(48, 38)
        btn_voltar.TabIndex = 26
        btn_voltar.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Coral
        Button4.Image = CType(resources.GetObject("Button4.Image"), Image)
        Button4.Location = New Point(329, 299)
        Button4.Name = "Button4"
        Button4.Size = New Size(143, 122)
        Button4.TabIndex = 27
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.HighlightText
        Label4.Location = New Point(315, 280)
        Label4.Name = "Label4"
        Label4.Size = New Size(175, 16)
        Label4.TabIndex = 28
        Label4.Text = "MOVIMENTO DE PESSOAS"
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.Coral
        Button5.Image = CType(resources.GetObject("Button5.Image"), Image)
        Button5.Location = New Point(100, 299)
        Button5.Name = "Button5"
        Button5.Size = New Size(143, 122)
        Button5.TabIndex = 29
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.ForeColor = SystemColors.HighlightText
        Label6.Location = New Point(124, 280)
        Label6.Name = "Label6"
        Label6.Size = New Size(91, 16)
        Label6.TabIndex = 30
        Label6.Text = "MATRÍCULAS"
        ' 
        ' frm_homerecepcao
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(578, 626)
        Controls.Add(Label6)
        Controls.Add(Button5)
        Controls.Add(Label4)
        Controls.Add(Button4)
        Controls.Add(btn_voltar)
        Controls.Add(Label5)
        Controls.Add(PictureBox1)
        Controls.Add(Label3)
        Controls.Add(Button3)
        Name = "frm_homerecepcao"
        StartPosition = FormStartPosition.CenterScreen
        Text = "HOME"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Button3 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btn_voltar As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Label6 As Label
End Class
