﻿Public Class frm_inicializacao
    Private Sub img_initialize_Click(sender As Object, e As EventArgs) Handles img_initialize.Click
        Formlogin.Show()
        Me.Hide()
    End Sub
End Class