﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_homeproprietario
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_homeproprietario))
        btn_voltar = New Button()
        SuspendLayout()
        ' 
        ' btn_voltar
        ' 
        btn_voltar.Image = CType(resources.GetObject("btn_voltar.Image"), Image)
        btn_voltar.Location = New Point(523, 12)
        btn_voltar.Name = "btn_voltar"
        btn_voltar.Size = New Size(48, 38)
        btn_voltar.TabIndex = 27
        btn_voltar.UseVisualStyleBackColor = True
        ' 
        ' frm_homeproprietario
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(594, 450)
        Controls.Add(btn_voltar)
        Name = "frm_homeproprietario"
        Text = "HOME"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btn_voltar As Button
End Class
