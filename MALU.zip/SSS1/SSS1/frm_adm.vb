﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frm_adm
    Private Sub btn_cadastrar_Click(sender As Object, e As EventArgs) Handles btn_cadastrar.Click
        Try
            If String.IsNullOrEmpty(txt_cpf.Text) Or String.IsNullOrEmpty(cmb_data.Value.Date) Or String.IsNullOrEmpty(txt_nome.Text) Or String.IsNullOrEmpty(cmb_id_cargo.Text) Or String.IsNullOrEmpty(txt_email.Text) Or String.IsNullOrEmpty(txt_cep.Text) Or String.IsNullOrEmpty(txt_rua.Text) Or String.IsNullOrEmpty(txt_n.Text) Or String.IsNullOrEmpty(txt_bairro.Text) Or String.IsNullOrEmpty(txt_uf.Text) Or String.IsNullOrEmpty(txt_wpp.Text) Or String.IsNullOrEmpty(txt_city.Text) Or String.IsNullOrEmpty(txt_bairro.Text) Or String.IsNullOrEmpty(diretorio) Then
                MsgBox("Preencha todos os campos!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "select * from tb_funcionarios where cpf = '" & txt_cpf.Text & "'"
                rs = db.Execute(sql)
                If rs.EOF = True Then
                    sql = "insert into tb_funcionarios (cpf, nome, email, id_cargo, endereco, num_telwpp, num_telfixo, data_nasc, cep, rua, bairro, cidade, num_residencial, complemento, uf) values ('" & txt_cpf.Text & "', '" & txt_nome.Text & "', '" & txt_email.Text & "', '" & cmb_id_cargo.Text & "', '" & diretorio & "', '" & txt_wpp.Text & "', '" & txt_telfixo.Text & "', '" & cmb_data.Value.Date & "', '" & txt_cep.Text & "', '" & txt_rua.Text & "', '" & txt_bairro.Text & "', '" & txt_city.Text & "', '" & txt_n.Text & "', '" & txt_comp.Text & "', '" & txt_uf.Text & "')"
                    rs = db.Execute(sql)
                    MsgBox("Cadastro realizado com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    carregar_dados()
                    limpar_campos_funcionarios()
                Else
                    resp = MsgBox("CPF já cadastrado! Deseja atualizar cadastro?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = vbYes Then
                        sql = "Update tb_funcionarios set nome = '" & txt_nome.Text & "', email = '" & txt_email.Text & "', id_cargo = '" & cmb_id_cargo.Text & "', endereco = '" & diretorio & "', num_telwpp = '" & txt_wpp.Text & "', num_telfixo = '" & txt_telfixo.Text & "', data_nasc = '" & cmb_data.Value.Date & "', cep = '" & txt_cep.Text & "', rua = '" & txt_rua.Text & "', bairro = '" & txt_bairro.Text & "', cidade = '" & txt_city.Text & "', num_residencial = '" & txt_n.Text & "', complemento = '" & txt_comp.Text & "', uf = '" & txt_uf.Text & "' where cpf = '" & txt_cpf.Text & "'"
                        rs = db.Execute(sql)
                        MsgBox("Dados alterados com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                        carregar_dados()
                        limpar_campos_funcionarios()
                    Else
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao cadastrar!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub foto_3x4_Click(sender As Object, e As EventArgs) Handles foto_3x4.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto!"
                .InitialDirectory = Application.StartupPath & "\Fotos_3x4"
                .ShowDialog()
                diretorio = .FileName
                foto_3x4.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub txt_cep_LostFocus(sender As Object, e As EventArgs) Handles txt_cep.LostFocus
        Try
            sql = "select * from tb_cep where cep='" & txt_cep.Text & "'"
            rs = db.Execute(sql)
            If rs.EOF = False Then
                txt_rua.Text = rs.Fields(1).Value
                txt_city.Text = rs.Fields(2).Value
                txt_bairro.Text = rs.Fields(3).Value
                txt_uf.Text = rs.Fields(4).Value
            Else
                resp = MsgBox("CEP não existente! Deseja cadastrá-lo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                If resp = vbYes Then
                    btn_salvar.Visible = True
                Else
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub txt_cpf_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf.LostFocus
        Try
            sql = "select * from tb_funcionarios where cpf='" & txt_cpf.Text & "'"
            rs = db.Execute(sql)
            If rs.EOF = False Then
                txt_nome.Text = rs.Fields(2).Value
                txt_email.Text = rs.Fields(3).Value
                cmb_id_cargo.Text = rs.Fields(4).Value
                foto_3x4.Load(rs.Fields(5).Value)
                txt_wpp.Text = rs.Fields(6).Value
                txt_telfixo.Text = rs.Fields(7).Value
                txt_cep.Text = rs.Fields(9).Value
                txt_rua.Text = rs.Fields(10).Value
                txt_bairro.Text = rs.Fields(11).Value
                txt_city.Text = rs.Fields(12).Value
                txt_n.Text = rs.Fields(13).Value
                txt_comp.Text = rs.Fields(14).Value
                txt_uf.Text = rs.Fields(15).Value
                btn_salvar.Visible = False
            Else
                txt_nome.Focus()
                btn_salvar.Visible = False
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar os dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub frm_adm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conectar_banco()
        carregar_dados()
        carregar_tipos()
        btn_salvar.Visible = False
    End Sub

    Private Sub txt_cpf_DoubleClick(sender As Object, e As EventArgs) Handles txt_cpf.DoubleClick
        limpar_campos_funcionarios()
    End Sub

    Private Sub txt_cpf_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_cpf.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_nome.Focus()
        End If
    End Sub

    Private Sub txt_nome_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_nome.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_email.Focus()
        End If
    End Sub

    Private Sub txt_email_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_email.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            cmb_id_cargo.Focus()
        End If
    End Sub

    Private Sub cmb_id_cargo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmb_id_cargo.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_cep.Focus()
        End If
    End Sub

    Private Sub txt_cep_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_cep.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_n.Focus()
        End If
    End Sub

    Private Sub txt_n_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_n.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_comp.Focus()
        End If
    End Sub

    Private Sub txt_wpp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_wpp.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_telfixo.Focus()
        End If
    End Sub

    Private Sub txt_telfixo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_telfixo.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_nome.Focus()
        End If
    End Sub

    Private Sub txt_comp_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_comp.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            txt_wpp.Focus()
        End If
    End Sub

    Private Sub btn_excluir_Click(sender As Object, e As EventArgs) Handles btn_excluir.Click
        Try
            If String.IsNullOrEmpty(txt_cpf.Text) Or String.IsNullOrEmpty(cmb_data.Value.Date) Or String.IsNullOrEmpty(txt_nome.Text) Or String.IsNullOrEmpty(cmb_id_cargo.Text) Or String.IsNullOrEmpty(txt_email.Text) Or String.IsNullOrEmpty(txt_cep.Text) Or String.IsNullOrEmpty(txt_rua.Text) Or String.IsNullOrEmpty(txt_n.Text) Or String.IsNullOrEmpty(txt_bairro.Text) Or String.IsNullOrEmpty(txt_uf.Text) Or String.IsNullOrEmpty(txt_wpp.Text) Or String.IsNullOrEmpty(txt_city.Text) Or String.IsNullOrEmpty(txt_bairro.Text) Or String.IsNullOrEmpty(diretorio) Then
                MsgBox("Preencha todos os campos!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "Select * from tb_funcionarios where cpf = '" & txt_cpf.Text & "'"
                rs = db.Execute(sql)
                If rs.EOF = True Then
                    MsgBox("Cadastro inexistente!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                Else
                    resp = MsgBox("Tem certeza que deseja excluir esse cadastro?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = vbNo Then
                    Else
                        sql = "delete from tb_funcionarios where cpf = '" & txt_cpf.Text & "'"
                        rs = db.Execute(sql)
                        MsgBox("Cadastro excluído com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                        carregar_dados()
                        limpar_campos_funcionarios()
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar os dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_salvar.Click
        Try
            If String.IsNullOrEmpty(txt_cep.Text) Or String.IsNullOrEmpty(txt_rua.Text) Or String.IsNullOrEmpty(txt_bairro.Text) Or String.IsNullOrEmpty(txt_uf.Text) Or String.IsNullOrEmpty(txt_city.Text) Then
                MsgBox("Preencha todos os campos!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "select * from tb_cep where cep = '" & txt_cep.Text & "'"
                rs = db.Execute(sql)
                If rs.EOF = True Then
                    sql = "insert into tb_cep values ('" & txt_cep.Text & "', '" & txt_rua.Text & "', '" & txt_city.Text & "', '" & txt_bairro.Text & "', '" & txt_uf.Text & "')"
                    rs = db.Execute(sql)
                    MsgBox("CEP cadastrado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    btn_salvar.Visible = False
                Else
                    MsgBox("Esse CEP já existe!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao consultar os dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub txt_busca_TextChanged(sender As Object, e As EventArgs) Handles txt_busca.TextChanged
        Try
            With dgv_dados
                sql = "select * from tb_funcionarios where " & cmb_tipo.Text & " like '" & txt_busca.Text & "%'"
                rs = db.Execute(sql)
                .Rows.Clear()
                Do While rs.EOF = False
                    .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(8).Value, rs.Fields(4).Value, rs.Fields(16).Value, rs.Fields(6).Value, rs.Fields(7).Value, rs.Fields(9).Value, rs.Fields(10).Value, rs.Fields(11).Value, rs.Fields(12).Value, rs.Fields(15).Value, rs.Fields(13).Value, rs.Fields(14).Value, Nothing, Nothing)
                    rs.MoveNext()
                Loop
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick
        Try
            With dgv_dados
                If .CurrentRow.Cells(17).Selected = True Then 'Apesar da coluna Editar ser chamada Column4, no código ela é considerada a coluna 3, pois a primeira é a 0
                    v_cpf = .CurrentRow.Cells(1).Value
                    resp = MsgBox("Deseja realmente excluir o" + vbNewLine &
                                  "CPF: " & v_cpf & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = vbYes Then
                        sql = "delete from tb_funcionarios where cpf = '" & v_cpf & "'"
                        rs = db.Execute(sql)
                        carregar_dados()
                    End If
                ElseIf .CurrentRow.Cells(16).Selected = True Then
                    v_cpf = .CurrentRow.Cells(1).Value
                    sql = "select * from tb_funcionarios where cpf = '" & v_cpf & "'"
                    rs = db.Execute(sql)
                    If rs.EOF = False Then
                        TabControl1.SelectTab(0)
                        txt_cpf.Text = rs.Fields(1).Value
                        txt_nome.Text = rs.Fields(2).Value
                        txt_email.Text = rs.Fields(3).Value
                        cmb_id_cargo.Text = rs.Fields(4).Value
                        foto_3x4.Load(rs.Fields(5).Value)
                        txt_wpp.Text = rs.Fields(6).Value
                        txt_telfixo.Text = rs.Fields(7).Value
                        cmb_data.Value = rs.Fields(8).Value
                        txt_cep.Text = rs.Fields(9).Value
                        txt_rua.Text = rs.Fields(10).Value
                        txt_bairro.Text = rs.Fields(11).Value
                        txt_city.Text = rs.Fields(12).Value
                        txt_n.Text = rs.Fields(13).Value
                        txt_comp.Text = rs.Fields(14).Value
                        txt_uf.Text = rs.Fields(15).Value
                    End If
                Else
                    Exit Sub
                End If
            End With
        Catch ex As Exception
            MsgBox("Erro ao consultar dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
End Class