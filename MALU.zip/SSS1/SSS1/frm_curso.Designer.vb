﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_curso
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_curso))
        PictureBox1 = New PictureBox()
        Label2 = New Label()
        txt_nome = New MaskedTextBox()
        Label1 = New Label()
        txt_cpf = New MaskedTextBox()
        Label5 = New Label()
        txt_id = New MaskedTextBox()
        Label6 = New Label()
        txt_curso = New MaskedTextBox()
        Label3 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BorderStyle = BorderStyle.Fixed3D
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(86, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(181, 175)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.ForeColor = SystemColors.HighlightText
        Label2.Location = New Point(12, 223)
        Label2.Name = "Label2"
        Label2.Size = New Size(192, 15)
        Label2.TabIndex = 14
        Label2.Text = "NOME COMPLETO DO PROFESSOR"
        ' 
        ' txt_nome
        ' 
        txt_nome.Location = New Point(12, 241)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(278, 23)
        txt_nome.TabIndex = 24
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.ForeColor = SystemColors.HighlightText
        Label1.Location = New Point(12, 290)
        Label1.Name = "Label1"
        Label1.Size = New Size(114, 15)
        Label1.TabIndex = 27
        Label1.Text = "CPF DO PROFESSOR"
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Location = New Point(12, 308)
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(278, 23)
        txt_cpf.TabIndex = 28
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.ForeColor = SystemColors.HighlightText
        Label5.Location = New Point(12, 357)
        Label5.Name = "Label5"
        Label5.Size = New Size(79, 15)
        Label5.TabIndex = 29
        Label5.Text = "ID DO CURSO"
        ' 
        ' txt_id
        ' 
        txt_id.Location = New Point(12, 375)
        txt_id.Name = "txt_id"
        txt_id.PasswordChar = "*"c
        txt_id.Size = New Size(100, 23)
        txt_id.TabIndex = 31
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.ForeColor = SystemColors.HighlightText
        Label6.Location = New Point(12, 423)
        Label6.Name = "Label6"
        Label6.Size = New Size(103, 15)
        Label6.TabIndex = 32
        Label6.Text = "NOME DO CURSO"
        ' 
        ' txt_curso
        ' 
        txt_curso.Location = New Point(12, 441)
        txt_curso.Name = "txt_curso"
        txt_curso.Size = New Size(278, 23)
        txt_curso.TabIndex = 33
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.ForeColor = SystemColors.HighlightText
        Label3.Location = New Point(12, 490)
        Label3.Name = "Label3"
        Label3.Size = New Size(59, 15)
        Label3.TabIndex = 34
        Label3.Text = "HORÁRIO"
        ' 
        ' frm_curso
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaptionText
        ClientSize = New Size(391, 569)
        Controls.Add(Label3)
        Controls.Add(txt_curso)
        Controls.Add(Label6)
        Controls.Add(txt_id)
        Controls.Add(Label5)
        Controls.Add(txt_cpf)
        Controls.Add(Label1)
        Controls.Add(txt_nome)
        Controls.Add(Label2)
        Controls.Add(PictureBox1)
        Name = "frm_curso"
        Text = "frm_curso"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_nome As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_id As MaskedTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_curso As MaskedTextBox
    Friend WithEvents Label3 As Label
End Class
